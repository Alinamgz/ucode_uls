#include "pathfinder.h"

void mx_struct_init(t_parsing *parse, t_matrix *matrix) {
    parse->bridge_line = NULL;
    parse->file_content = NULL;
    parse->islands = NULL;
    parse->lines = NULL;
    parse->temp_island = NULL;
    parse->number_bridges = 0;
    parse->number_of_island = 0;
    parse->parse_comma = NULL;
    parse->all_island = NULL;
    parse->parse_def = NULL;
    parse->bridge_value = 0;

    matrix->path_dist = 0;
    matrix->prime_table = 0;
    matrix->route = NULL;
    matrix->len = 0;
}
