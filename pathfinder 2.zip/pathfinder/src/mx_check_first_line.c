#include "libmx.h"

void mx_check_first_line(char **str) {
    
    int i = 0;
    if(str[0][i] == '\0' || str[0][i] == '\n') {
        mx_printerr("error:line 1 is not valid\n");
        free(*str);
        exit(1);
    }
    
    for(int a = 0; str[0][a] != '\n'; a++) {
        if(!mx_isdigit(str[0][a])){
            mx_printerr("error:line 1 is not valid\n");
            exit(1);
        }
    }
}
