#include "pathfinder.h"

int main( int argc, char *argv[]) {
    t_parsing *parse =(t_parsing *)malloc(sizeof(t_parsing));
    t_matrix *matrix = (t_matrix *)malloc(sizeof(t_matrix));
    mx_check_arguments(argc);
    mx_struct_init(parse, matrix);
    mx_all_errors(argc, argv, parse);
    mx_matrix(parse, matrix);
    mx_floyd_algorithm(parse, matrix);
    mx_output_results(parse, matrix);
    return 0;
    
}
