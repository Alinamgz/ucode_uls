#include "pathfinder.h"

void mx_print_error_line(int *line) {
    char *num = mx_itoa(*line + 1);
    mx_printerr("error: line ");
    mx_printerr(num);
    mx_printerr(" is not valid\n");
    free(num);
    exit(1);
}
