#include "pathfinder.h"

void mx_check_lines(t_parsing *parse,  char **str, int *lines) {
    int line = *lines;
   
    parse->lines = mx_strsplit(*str, '\n');

    for(; parse->lines[line] != NULL; line++) {
        int j = 1;
        int k = 1;
        for(int i = 0; parse->lines[line][i] != '-' ; i++) {
            if(parse->lines[line][i] == '-') {
                mx_print_error_line(&line);
                exit(1);
            }
            if(!mx_isalpha(parse->lines[line][i])){
                mx_print_error_line(&line);
                exit(1);
            }
        }
        for(int i = 0; parse->lines[line][i] != '-' ; i++)
        j++;
        for(int i = 0; parse->lines[line][i] != ','; i++)
        k++;
        
        if(parse->lines[line][j] == ',' || (parse->lines[line][j] == '-')){
            mx_print_error_line(&line);
            exit(1);
        }
        for(; parse->lines[line][j] != ','; j++){
            if(!mx_isalpha(parse->lines[line][j])){
                mx_print_error_line(&line);
                exit(1);
            }
        if(parse->lines[line][k] == ',' || parse->lines[line][k] == '\n'|| parse->lines[line][k] == '-') {
            mx_print_error_line(&line);
            exit(1);
        }
        for(; parse->lines[line][k]; k++){
            if(!mx_isdigit(parse->lines[line][k])){
                mx_print_error_line(&line);
                exit(1);
            }
        }   
        }
    }
    mx_del_strarr(&parse->lines);
}
