#include "pathfinder.h"

static void mx_print_boundary() {
    for (int i = 0; i++ < 40; mx_printstr("="));
    mx_printstr("\n");
}
static bool check_shortest_path(t_matrix *matrix, int k) {
    int i = matrix->route[matrix->len];
    int j = matrix->route[0];

    if (matrix->prime_table[i][k] == matrix->path_dist[i][j] - matrix->path_dist[k][j])
        return true;
    return false;
}
static void print_path_and_route(t_parsing *parse, t_matrix *matrix) {
    mx_print_boundary();
    mx_printstr("Path: ");
    mx_printstr(parse->islands[matrix->route[1]]);
    mx_printstr(" -> ");
    mx_printstr(parse->islands[matrix->route[matrix->len]]);
    mx_printstr("\n");
    mx_printstr("Route: ");
    for (int i = 1; i < matrix->len + 1; ) {
        mx_printstr(parse->islands[matrix->route[i]]);
        ++i < matrix->len + 1 ? mx_printstr(" -> ") : mx_printstr("");
    }
    mx_printstr("\n");
}
static void print_distance(t_matrix *matrix) {
    int sum = 0;

    mx_printstr("Distance: ");
    for (int i = 1; i < matrix->len; i++){
        mx_printint(matrix->prime_table[matrix->route[i]][matrix->route[i + 1]]);
        sum += matrix->prime_table[matrix->route[i]][matrix->route[i + 1]];
        if (i < matrix->len - 1)
            mx_printstr(" + ");
        else if (i > 1) {
            mx_printstr(" = ");
            mx_printint(sum);
        }
    }
    mx_printstr("\n");
    mx_print_boundary();
}
static void print_shortest_path(t_parsing *parse, t_matrix *matrix) {
    for (int k = 0; k < parse->number_of_island; k++) {
        if (k != matrix->route[matrix->len]
            && check_shortest_path(matrix, k)) {
            matrix->route[++matrix->len] = k;
            print_shortest_path(parse, matrix);
            matrix->len--;
        }
    }
    if (matrix->route[matrix->len] != matrix->route[0])
        return;
    print_path_and_route(parse, matrix);
    print_distance(matrix);
}

void mx_output_results(t_parsing *parse, t_matrix *matrix) {
    for (int i = 0; i < parse->number_of_island; i++) {
        for (int j = i + 1; j < parse->number_of_island; j++) {
            matrix->route = (int *)malloc(sizeof(int) * (parse->number_of_island));
            matrix->len = 1;
            matrix->route[0] = j;
            matrix->route[matrix->len] = i;
            print_shortest_path(parse, matrix);
            free(matrix->route);
        }
    }
}
