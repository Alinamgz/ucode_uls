#include "pathfinder.h"

void mx_all_errors(int argc, char **argv, t_parsing *parse) {
    int line = 1;
    int fd = 0;
    char ch;
    int amount = 0;
    mx_check_arguments(argc);
    fd = open(argv[1], O_RDONLY);
    if(fd < 0) {
        mx_printerr("error: file ");
        mx_printerr(argv[1]);
        mx_printerr(" does not exist\n");
        close(fd);
        exit(1);
    }
    for ( ; read(fd, &ch, 1); amount++);
    if (amount <= 0) {
        mx_printerr("error: file ");
        mx_printerr(argv[1]);
        mx_printerr(" is empty\n");
        close(fd);
        exit(1);
    close(fd);
    }
    parse->file_content = mx_file_to_str(argv[1]);
    mx_check_first_line(&parse->file_content);
    mx_check_lines(parse, &parse->file_content, &line);
    mx_parsing(parse, &line);
    free(parse->file_content);
}
