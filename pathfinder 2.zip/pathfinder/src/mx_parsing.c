#include "pathfinder.h"

static void mx_unique_island(t_parsing *parse, int *count) {
    int i = 0;
    if (*count != 0) {
        for ( ; parse->islands[i] != NULL; i++) {
            if (!mx_strcmp(parse->islands[i], parse->temp_island))
                return;
        }
    }
    parse->islands[i] = mx_strdup(parse->temp_island);
    *count += 1;
}
static void mx_dup_brigdes(t_parsing *parse) {
   char **island1 = NULL;
   char **island2 = NULL;

   for(int i = 0; i < parse->number_bridges; i++){
       island1 = mx_strsplit(parse->bridge_line[i], '-');
       for(int j = i + 1; j < parse->number_bridges; j++){
           island2 = mx_strsplit(parse->bridge_line[j], '-');
           if(!mx_strcmp(parse->bridge_line[i], parse->bridge_line[j])){
           mx_del_strarr(&island1);
           mx_del_strarr(&island2);
           mx_printerr("error: duplicate bridges\n");
           exit(1);
           }
           if(!mx_strcmp(island1[0], island2[1]) 
                && !mx_strcmp(island1[1], island2[0])) {
                mx_del_strarr(&island1);
                mx_del_strarr(&island2);
                mx_printerr("error: duplicate bridges\n");
                exit(1);
            }
          mx_del_strarr(&island2);
        }
        mx_del_strarr(&island1);
   }
mx_del_strarr(&parse->bridge_line);
}
static void mx_invalid_num(t_parsing *parse, int *count) {
    if(*(count) != parse->number_of_island){
        mx_del_strarr(&parse->lines);
        mx_del_strarr(&parse->bridge_line);
        free(parse->file_content);
        free(parse->bridge_value);
        free(parse);
        mx_printerr("invalid number of islands\n");
        exit(1);
    }
}
void mx_parsing(t_parsing *parse, int *lines) {
    long sum = 0;
    int count = 0;
    int m = -1;

    parse->lines = mx_strsplit(parse->file_content, '\n');
    parse->number_of_island = mx_atoi(parse->lines[0]);

    for(int i = 0; parse->lines[i + 1] != NULL; i++) {
        parse->number_bridges++;
    }
    parse->bridge_line = (char **)malloc(sizeof(char *) * parse->number_bridges + 1);
    parse->islands = (char**)malloc(sizeof(char *) * parse->number_of_island + 1);
    parse->all_island = (char **)malloc(sizeof(char **) * parse->number_bridges + 1);
    parse->bridge_value = (long *)malloc(sizeof(long *) * parse->number_bridges + 1);

    for (int k = 0; k <= parse->number_of_island; k++){
        parse->islands[k] = NULL;}
    for (int k = 0; k <= parse->number_bridges; k++) {
        parse->bridge_line[k] = NULL;}
    for (int k = 0; k <= parse->number_bridges*2; k++) {
        parse->all_island[k] = NULL;}


    for(; parse->lines[*lines] != NULL ; (*lines)++){
        parse->parse_comma = mx_strsplit(parse->lines[*lines], ',');
        parse->parse_def = mx_strsplit(parse->parse_comma[0], '-');
        if(mx_strcmp(parse->parse_def[0], parse->parse_def[1]) == 0){
            mx_del_strarr(&parse->parse_comma);
            mx_del_strarr(&parse->parse_def);
            mx_print_error_line(lines);
        }
        parse->bridge_value[*lines - 1] = mx_atol(parse->parse_comma[1]);
        sum += parse->bridge_value[*lines - 1];
            if(sum > INT_MAX) {
                mx_printerr("error: sum of bridges lengths is too big\n");
                exit(1);
            }
        parse->bridge_line[*lines - 1] = mx_strdup(parse->parse_comma[0]);
        parse->all_island[++m] = mx_strdup(parse->parse_def[0]);
        parse->all_island[++m] = mx_strdup(parse->parse_def[1]);
        parse->temp_island = mx_strdup(parse->parse_def[0]);
        mx_unique_island(parse, &count);
        free(parse->temp_island);
        parse->temp_island = mx_strdup(parse->parse_def[1]);
        mx_unique_island(parse, &count);
        free(parse->temp_island);
        mx_del_strarr(&parse->parse_comma);
        mx_del_strarr(&parse->parse_def);

    }
    mx_dup_brigdes(parse); 
    mx_invalid_num(parse, &count); 
    mx_del_strarr(&parse->bridge_line);
}
