#include "pathfinder.h"

void mx_floyd_algorithm(t_parsing *parse, t_matrix *matrix) {
    long sum = 0;

    for(int y = 0; y < parse->number_of_island; y++) {
        for(int x = 0; x < parse->number_of_island; x++) {
            matrix->prime_table[y][x] = matrix->path_dist[y][x];
            matrix->prime_table[x][y] = matrix->path_dist[x][y];
        }
    }
    for(int y = 0; y < parse->number_of_island; y++) {
        for(int x = 0; x < parse->number_of_island; x++) {
            for(int k = x + 1; k < parse->number_of_island; k++) {
                sum = matrix->path_dist[y][k] + matrix->path_dist[x][y];
                if(matrix->path_dist[x][k] > sum) {
                    matrix->path_dist[x][k] = sum;
                    matrix->path_dist[k][x] = sum;
                }
            }
        }
    } 
}   
