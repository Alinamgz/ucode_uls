#include "pathfinder.h"

static int island_index(t_parsing *parse, char *island) {
    for(int i = 0; i < parse->number_of_island; i++){
        if(!mx_strcmp(island, parse->islands[i]))
            return i;
    }
    return 0;
}

void mx_matrix(t_parsing *parse, t_matrix *matrix) {
    
    int x;
    int y;
    char **buf = NULL;
    char ** comma;
    int num = 0;
    
    buf = (char **)malloc(sizeof(char*)*parse->number_bridges);
    matrix->path_dist = (long **)malloc((sizeof(long *) * parse->number_of_island));
    matrix->prime_table = (long **)malloc((sizeof(long *) * parse->number_of_island));
    for (int y = 0; y < parse->number_of_island; y++) {
        matrix->path_dist[y] = (long *)malloc(sizeof(long) * parse->number_of_island);
        matrix->prime_table[y] = (long *)malloc((sizeof(long *) * parse->number_of_island));
    }
    for (int y = 0; y < parse->number_of_island; y++) {
        for (int x = 0; x < parse->number_of_island; x++) {
            matrix->path_dist[y][x] = (y == x ? 0 : INT_MAX);
        }
    }
    for(int i = 1; i <= parse->number_bridges; i++) {
        comma = mx_strsplit(parse->lines[i], ',');
        buf[i - 1] = mx_strdup(comma[1]); 
        mx_del_strarr(&comma);
    }
    for(int i = 0; i < parse->number_bridges*2; i +=2) {
        x = island_index(parse, parse->all_island[i]);
        y = island_index(parse, parse->all_island[i + 1]);
        matrix->path_dist[x][y] = mx_atoi(buf[num++]);
        matrix->path_dist[y][x] =  matrix->path_dist[x][y];
        
    }
   
    mx_del_strarr(&comma);
    for(int i = 0; i < parse->number_bridges; i++)
        mx_strdel(&buf[i]);
    free(buf);

    mx_del_strarr(&parse->lines);
    for(int i = 0; i < parse->number_bridges*2; i++)
        mx_strdel(&parse->all_island[i]);
}

