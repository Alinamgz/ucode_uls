#include "libmx.h"

double mx_pow(double n, unsigned int pow) {
    unsigned int i = 1;
    double a = 1;
    for(; i <= pow; i++) {
        a = a * n;
        }
    return a;
}

