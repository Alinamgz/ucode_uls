#include "libmx.h"

char* mx_nbr_to_hex(unsigned long nbr) {
    int rslt = nbr;
    char *ptr = NULL;
    int size = 0;
    int div = 0;
   for(; nbr > 0; size++) {
       nbr /= 16;
    }
    ptr = (char *) malloc(sizeof(char) * (size + 1)); 
    if(!ptr)
        return  NULL;
    for(; size > 0; size--) {
        nbr = rslt;
        rslt = nbr / 16;
        div = nbr % 16;
        if(div >= 10) 
            ptr[size - 1] = (div + 87);
        else 
            ptr[size - 1] = (div + 48);
        }
    return ptr;
    }
