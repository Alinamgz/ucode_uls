#include "libmx.h"

void mx_pop_front(t_list **head) {
    
    t_list *tmp = *head;
        if(head && *head) 
        *head = (*head)->next;
        free(tmp);
}
