#include "libmx.h"

void mx_del_strarr(char ***arr) {
    if (arr != NULL && *arr != NULL) {

        char **strings = *arr;
        int count = 0;

        while (strings[count])
            mx_strdel(&strings[count++]);

        free(*arr);
        *arr = NULL;
    }
}
