#include "libmx.h"

int mx_get_substr_index(const char *str, const char *sub) {
    int len = 0;
    int i = 0;

    if(sub && str) {
        len = mx_strlen(sub);
        while(*str) {
            if(mx_strncmp(str, sub, len) == 0)
                return i;
            str++;
            i++;
        }
        return -1;
    }
    return -2;
}
