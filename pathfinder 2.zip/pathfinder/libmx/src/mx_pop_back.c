#include "libmx.h"

void mx_pop_back(t_list **head) {
    t_list *tmp, *prev_list;
    if (*head == NULL || head == NULL)
        return;
    if ((*head)->next == NULL) {
        free(*head);
        *head = NULL;
    }
    tmp = *head;
    while(tmp->next != 0) {
        prev_list = tmp;
        tmp = tmp->next;
    } 
    prev_list->next = NULL;
    free(tmp);
}
