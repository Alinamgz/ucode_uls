#pragma once 

#include <libmx.h>
#include <stdio.h>


typedef struct file_parsing {
    int number_of_island;
    int number_bridges;
    long *bridge_value;
    char **bridge_line;
    char **lines;
    char **parse_def;
    char **parse_comma;
    char **islands;
    char **all_island;
    char *temp_island;
    char *file_content;
}               t_parsing;

typedef struct matrix{
    long **path_dist;
    long **prime_table;
    int len;
    int *route;
}              t_matrix;

void mx_error_file_empty(char *file);
void mx_check_file_exist(char *file);
void mx_check_first_line(char **str);
void mx_check_arguments(int argc);
void mx_all_errors(int argc, char **argv, t_parsing *parse);
void mx_check_lines(t_parsing *parse,  char **str, int *lines);
void mx_print_error_line(int *line);
void mx_struct_init(t_parsing *parse, t_matrix *matrix);
void mx_parsing(t_parsing *parse, int *lines);
void mx_matrix(t_parsing *parse, t_matrix *matrix);
void mx_floyd_algorithm(t_parsing *parse, t_matrix *matrix);

void mx_output_results(t_parsing *parse, t_matrix *matrix);

// void mx_output_generating(t_parsing *parse, t_matrix *matrix, int i, int j);
// void mx_output_recursive_algorithm(t_parsing *parse, t_matrix *matrix);
// void mx_output_boundary(void);
// void mx_output_path(t_parsing *parse, t_matrix *matrix);
// void mx_output_way(t_parsing *parse, t_matrix *matrix);
// void mx_output_distance(t_matrix *matrix);
//void mx_print_boundary();
